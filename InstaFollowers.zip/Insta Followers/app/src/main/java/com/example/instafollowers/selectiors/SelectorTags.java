package com.example.instafollowers.selectiors;

public class SelectorTags {

    public static String USERNAME_SELECTOR = "#react-root > section > main > div > header > section > div.XBGH5 > h2";
    public static String PICTURES_SELECTOR = "#react-root > section > main > div > div._2z6nI > article > div:nth-child(1) > div > div:nth-child(1) > div:nth-child(1) > a > div.eLAPa > div.KL4Bh";
}