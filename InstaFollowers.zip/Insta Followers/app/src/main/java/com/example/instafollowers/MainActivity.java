package com.example.instafollowers;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import com.example.instafollowers.databinding.ActivityMainBinding;
import com.example.instafollowers.selectiors.PageTags;
import com.example.instafollowers.selectiors.SelectorTags;

import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Attribute;
import org.jsoup.nodes.Attributes;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;



    @SuppressLint("JavascriptInterface")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());



        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Document doc = null;
                    Connection connection = null;

                   // connection = Jsoup.connect("https://www.imdb.com/chart/top");
                    doc  = Jsoup.connect(PageTags.INSTAGRAM_PROFILE).timeout(8000).get();


                  //  Elements elements = doc.getAllElements();
                    Elements elements = doc.select("a[href]");
                    Log.v("DIV", "Pronadjeno " + elements.size() + " elemenata");
/*
                    for (Element element : body) {

                        Log.v("PODACI", element.text());
                    }

 */
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }
        }).start();

    }

/*

    @Override
    public void onBackPressed() {
        if(webView.canGoBack())
            webView.goBack();
        else
            super.onBackPressed();
    }
    */

}




/*

 private WebView webView;
    private WebSettings webSettings;

        android.webkit.WebView webView =  binding.webView;
        webView.setWebViewClient(new WebViewClient());
        webSettings = webView.getSettings();

        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.getSettings().setAllowUniversalAccessFromFileURLs(true);
        webView.getSettings().setAllowContentAccess(true);
        webView.getSettings().setAppCacheEnabled(true);
        //also check this line of code for appCachePath
        String appCachePath = this.getCacheDir().getAbsolutePath();
        webSettings.setAppCachePath(appCachePath);

        webView.setScrollContainer(false);
        webView.addJavascriptInterface(new JavascriptAccessor(), "javascriptAccessor");

        //execute asynctTask
        ExecutorService executor = Executors.newSingleThreadExecutor();
        Handler handler = new Handler(Looper.getMainLooper());

        executor.execute(() -> {

            //webView.loadUrl("https://www.instagram.com/mirko_stojanovic_/");

            handler.post(() -> webView.loadUrl("https://www.instagram.com/mirko_stojanovic_/"));
        });
        */