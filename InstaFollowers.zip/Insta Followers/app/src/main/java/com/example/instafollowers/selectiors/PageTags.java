package com.example.instafollowers.selectiors;

public class PageTags {

    public static String INSTAGRAM_PROFILE = "https://www.instagram.com/mirko_stojanovic_/";

}
